import { Layout } from '../../components';

export const NotFound = () => {
    return (
        <Layout>
            Not Found
        </Layout>
    )
};