import { Layout } from '../../components';

export const Account = () => {
    return (
        <Layout>
            Account
        </Layout>
    )
};