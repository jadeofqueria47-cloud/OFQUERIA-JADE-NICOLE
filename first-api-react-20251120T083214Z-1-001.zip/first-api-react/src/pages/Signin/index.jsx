import { Layout } from '../../components';

export const Signin = () => {
    return (
        <Layout>
            Sign in
        </Layout>
    )
};